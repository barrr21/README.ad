package com.example.kalkulatorutmj

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    private lateinit var txtScreen: TextView

    private var angka = ""
    private var operasi = ""
    private var angkaSebelumnya = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtScreen = findViewById(R.id.txtScreen)

        // Angka
        angkaClick(R.id.btn0)
        angkaClick(R.id.btn1)
        angkaClick(R.id.btn2)
        angkaClick(R.id.btn3)
        angkaClick(R.id.btn4)
        angkaClick(R.id.btn5)
        angkaClick(R.id.btn6)
        angkaClick(R.id.btn7)
        angkaClick(R.id.btn8)
        angkaClick(R.id.btn9)

        // Titik
        findViewById<Button>(R.id.btnPoint).setOnClickListener {
            if (!angka.contains(".")) {
                angka += "."
                updateScreen()
            }
        }

        // Operasi
        operasiClick(R.id.btnAdd, "+")
        operasiClick(R.id.btnSubtract, "-")
        operasiClick(R.id.btnMultiply, "*")
        operasiClick(R.id.btnDivide, "/")

        // Persen
        findViewById<Button>(R.id.btnPercent).setOnClickListener {
            if (angka.isNotEmpty()) {
                angka = (angka.toDouble() / 100).toString()
                updateScreen()
            }
        }

        // Akar Kuadrat
        findViewById<Button>(R.id.btnSqrt).setOnClickListener {
            if (angka.isNotEmpty()) {
                angka = sqrt(angka.toDouble()).toString()
                updateScreen()
            }
        }

        // Sama dengan
        findViewById<Button>(R.id.btnEquals).setOnClickListener {
            hitungHasil()
        }

        // Clear
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            angka = ""
            angkaSebelumnya = ""
            operasi = ""
            updateScreen()
        }
    }

    private fun angkaClick(id: Int) {
        findViewById<Button>(id).setOnClickListener {
            angka += (it as Button).text.toString()
            updateScreen()
        }
    }

    private fun operasiClick(id: Int, op: String) {
        findViewById<Button>(id).setOnClickListener {
            if (angka.isNotEmpty()) {
                angkaSebelumnya = angka
                angka = ""
                operasi = op
                updateScreen()
            }
        }
    }

    private fun hitungHasil() {
        if (angkaSebelumnya.isEmpty() || angka.isEmpty()) return

        val a = angkaSebelumnya.toDouble()
        val b = angka.toDouble()
        var hasil = 0.0

        when (operasi) {
            "+" -> hasil = a + b
            "-" -> hasil = a - b
            "*" -> hasil = a * b
            "/" -> hasil = a / b
        }

        angka = hasil.toString()
        operasi = ""
        angkaSebelumnya = ""
        updateScreen()
    }

    private fun updateScreen() {
        txtScreen.text = angka
    }
}
